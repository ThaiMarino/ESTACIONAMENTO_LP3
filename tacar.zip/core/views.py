from django.shortcuts import render

# Create your views here.

# toda funcao recebe um request
def home(request):
    return render(request, 'core/index.html')

# declarar a funcao que acabamos de criar
def cadastro_cliente(request):
    return render(request, 'core/cadastro_cliente.html')

def listagem_clientes(request):
    return render(request, 'core/listagem_clientes.html')

def cadastro_veiculo(request):
    return render(request, 'core/cadastro_veiculo.html')

def listagem_veiculos(request):
    return render(request, 'core/listagem_veiculos.html')

def cadastro_tabela(request):
    return render(request, 'core/cadastro_tabela.html')

def listagem_tabelas(request):
    return render(request, 'core/listagem_tabelas.html')